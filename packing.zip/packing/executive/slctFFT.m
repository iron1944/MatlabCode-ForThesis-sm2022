%% load
fftRead
%%
% find the id for the selected periods
L = 85;
T = 60^2*24*365;
f = (1/T)*(0:(L/2))/L;
p = f.^(-1)/T;

p_slct = [18 9 5 3];

%% JPL
FFTplots(F_JPL,p_slct,1,1);
FFTplots(F_JPL,p_slct,1,2);
FFTplots(F_JPL,p_slct,1,3);
%% NCAR
FFTplots(F_NCAR,p_slct,2,1);
FFTplots(F_NCAR,p_slct,2,2);
FFTplots(F_NCAR,p_slct,2,3);
%% PIK1
FFTplots(F_PIK1,p_slct,3,1);
FFTplots(F_PIK1,p_slct,3,2);
FFTplots(F_PIK1,p_slct,3,3);
%% PIK2
FFTplots(F_PIK2,p_slct,4,1);
FFTplots(F_PIK2,p_slct,4,2);
FFTplots(F_PIK2,p_slct,4,3);
%% UAF1
FFTplots(F_UAF1,p_slct,5,1);
FFTplots(F_UAF1,p_slct,5,2);
FFTplots(F_UAF1,p_slct,5,3);