%% JPL
for i = 1:3
    [Odom_ISSM{i},logic{i}]=Odom(dsdt_JPL,i,1);
end
%% NCAR
for i = 1:3
    Odom_CISM{i}=Odom(dsdt_NCAR,i,2);
end
%% ILTS PIK1
for i = 1:3
    Odom_SIC1{i}=Odom(dsdt_PIK1,i,3);
end
%% ILTS PIK1
for i = 1:3
    Odom_SIC2{i}=Odom(dsdt_PIK2,i,4);
end
%% PISM1
for i = 1:3
    Odom_PISM1{i}=Odom(dsdt_UAF1,i,5);
end

%% 