%% Preparation

% Loading data
Data_clearup
fftRead

% prepare x/y coordinate for plotting
[x2d,y2d] = meshgrid((1:337),(1:577));

% read data coordinate
readcoor

%% Reading flowline coordinate

% Zachariae
F_ZAC.psx = ncread('glacier0115.nc','/flowline03/x');
F_ZAC.psy = ncread('glacier0115.nc','/flowline03/y');

%% extract important info

F_ZAC = FLconv(F_ZAC);

%% interpolate FFT and thickness change

% ZAC
[FFT_ZAC.JPL,dh_ZAC.JPL] = FFTdhGrab(F_ZAC,dsdt_JPL,F_JPL);
[FFT_ZAC.NCAR,dh_ZAC.NCAR] = FFTdhGrab(F_ZAC,dsdt_NCAR,F_NCAR);
[FFT_ZAC.PIK1,dh_ZAC.PIK1] = FFTdhGrab(F_ZAC,dsdt_PIK1,F_PIK1);
[FFT_ZAC.PIK2,dh_ZAC.PIK2] = FFTdhGrab(F_ZAC,dsdt_PIK2,F_PIK2);
[FFT_ZAC.UAF1,dh_ZAC.UAF1] = FFTdhGrab(F_ZAC,dsdt_UAF1,F_UAF1);

%% plots
FLname = ['Zachariae Isstrom'];

FL_plots(F_ZAC,FFT_ZAC.JPL,1,FLname)
FL_plots(F_ZAC,FFT_ZAC.NCAR,2,FLname)
FL_plots(F_ZAC,FFT_ZAC.PIK1,3,FLname)
FL_plots(F_ZAC,FFT_ZAC.PIK2,4,FLname)
FL_plots(F_ZAC,FFT_ZAC.UAF1,5,FLname)

%% ID cwt target
targetID = [544 4612 5615 10018];
% 544 is @ 27 km @ outlet glacier, 4612(230km) and 5615(280km) are @ the
% anomaly, and 10018 is @ inland region
target = F_ZAC.dist(targetID);
ts = years(F_ZAC.yr)';
%% SICOPOLIS2
cwtCtrl(dh_ZAC.PIK2,ts,target,targetID,4,1)
cwtCtrl(dh_ZAC.PIK2,ts,target,targetID,4,2)
cwtCtrl(dh_ZAC.PIK2,ts,target,targetID,4,3)
%% Lateral 
cwtCtrl(dh_ZAC.JPL,ts,target,targetID,1,3)
cwtCtrl(dh_ZAC.NCAR,ts,target,targetID,2,3)
cwtCtrl(dh_ZAC.PIK1,ts,target,targetID,3,3)
cwtCtrl(dh_ZAC.UAF1,ts,target,targetID,5,3)