%% JPL-ISSM
v11 = VideoWriter('JPL-ISSM_MIROC5.avi');
v11.FrameRate = 1;
fr_JPL1 = animate(dsdt_JPL,1,1);
open(v11);
writeVideo(v11,fr_JPL1);
close(v11);

v12 = VideoWriter('JPL-ISSM_NorESM.avi');
v12.FrameRate = 1;
fr_JPL2 = animate(dsdt_JPL,2,1);
open(v12);
writeVideo(v12,fr_JPL2);
close(v12);

v13 = VideoWriter('JPL-ISSM_CSIRO3.avi');
v13.FrameRate = 1;
fr_JPL3 = animate(dsdt_JPL,3,1);
open(v13);
writeVideo(v13,fr_JPL3);
close(v13);
%% NCAR-CISM
v21 = VideoWriter('NCAR-CISM_MIROC5.avi');
v21.FrameRate = 1;
fr_NCAR1 = animate(dsdt_NCAR,1,2);
open(v21);
writeVideo(v21,fr_NCAR1);
close(v21);

v22 = VideoWriter('NCAR-CISM_NorESM.avi');
v22.FrameRate = 1;
fr_NCAR2 = animate(dsdt_NCAR,2,2);
open(v22);
writeVideo(v22,fr_NCAR2);
close(v22);

v23 = VideoWriter('NCAR-CISM_CSIRO3.avi');
v23.FrameRate = 1;
fr_NCAR3 = animate(dsdt_NCAR,3,2);
open(v23);
writeVideo(v23,fr_NCAR3);
close(v23);
%% ILTS_PIK-SICOPOLIS1
v31 = VideoWriter('SICOPOLIS1_MIROC5.avi');
v31.FrameRate = 1;
fr_PIK11 = animate(dsdt_PIK1,1,3);
open(v31);
writeVideo(v31,fr_PIK11);
close(v31);

v32 = VideoWriter('SICOPOLIS1_NorESM.avi');
v32.FrameRate = 1;
fr_PIK12 = animate(dsdt_PIK1,2,3);
open(v32);
writeVideo(v32,fr_PIK12);
close(v32);

v33 = VideoWriter('SICOPOLIS1_CSIRO3.avi');
v33.FrameRate = 1;
fr_PIK13 = animate(dsdt_PIK1,3,3);
open(v33);
writeVideo(v33,fr_PIK13);
close(v33);
%% ILTS_PIK-SICOPOLIS2
v41 = VideoWriter('SICOPOLIS2_MIROC5.avi');
v41.FrameRate = 1;
fr_PIK21 = animate(dsdt_PIK2,1,4);
open(v41);
writeVideo(v41,fr_PIK21);
close(v41);

v42 = VideoWriter('SICOPOLIS2_NorESM.avi');
v42.FrameRate = 1;
fr_PIK22 = animate(dsdt_PIK2,2,4);
open(v42);
writeVideo(v42,fr_PIK22);
close(v42);

v43 = VideoWriter('SICOPOLIS2_CSIRO3.avi');
v43.FrameRate = 1;
fr_PIK23 = animate(dsdt_PIK2,3,4);
open(v43);
writeVideo(v43,fr_PIK23);
close(v43);
%% UAF-PISM1
v51 = VideoWriter('UAF-PISM1_MIROC5.avi');
v51.FrameRate = 1;
fr_UAF11 = animate(dsdt_UAF1,1,5);
open(v51);
writeVideo(v51,fr_UAF11);
close(v51);

v52 = VideoWriter('UAF-PISM1_NorESM.avi');
v52.FrameRate = 1;
fr_UAF12 = animate(dsdt_UAF1,2,5);
open(v52);
writeVideo(v52,fr_UAF12);
close(v52);

v53 = VideoWriter('UAF-PISM1_CSIRO3.avi');
v53.FrameRate = 1;
fr_UAF13 = animate(dsdt_UAF1,3,5);
open(v53);
writeVideo(v53,fr_UAF13);
close(v53);
%% Forcing vs. CM
%% MIROC5
Ful_1= VideoWriter('Full_MIROC5.avi');
Ful_1.FrameRate = 1;
fr_F1 = CMMovie(1,1,dsdt_JPL, dsdt_NCAR, dsdt_PIK1, dsdt_PIK2, dsdt_UAF1);
open(Ful_1);
writeVideo(Ful_1,fr_F1);
close(Ful_1);

AO_1= VideoWriter('AO_MIROC5.avi');
AO_1.FrameRate = 1;
fr_A1 = CMMovie(1,2,dsdt_JPL, dsdt_NCAR, dsdt_PIK1, dsdt_PIK2, dsdt_UAF1);
open(AO_1);
writeVideo(AO_1,fr_A1);
close(AO_1);

OO_1= VideoWriter('OO_MIROC5.avi');
OO_1.FrameRate = 1;
fr_O1 = CMMovie(1,3,dsdt_JPL, dsdt_NCAR, dsdt_PIK1, dsdt_PIK2, dsdt_UAF1);
open(OO_1);
writeVideo(OO_1,fr_O1);
close(OO_1);
%% NorESM
Ful_2= VideoWriter('Full_NorESM.avi');
Ful_2.FrameRate = 1;
fr_F2 = CMMovie(2,1,dsdt_JPL, dsdt_NCAR, dsdt_PIK1, dsdt_PIK2, dsdt_UAF1);
open(Ful_2);
writeVideo(Ful_2,fr_F2);
close(Ful_2);

AO_2= VideoWriter('AO_NorESM.avi');
AO_2.FrameRate = 1;
fr_A2 = CMMovie(2,2,dsdt_JPL, dsdt_NCAR, dsdt_PIK1, dsdt_PIK2, dsdt_UAF1);
open(AO_2);
writeVideo(AO_2,fr_A2);
close(AO_2);

OO_2= VideoWriter('OO_NorESM.avi');
OO_2.FrameRate = 1;
fr_O2 = CMMovie(2,3,dsdt_JPL, dsdt_NCAR, dsdt_PIK1, dsdt_PIK2, dsdt_UAF1);
open(OO_2);
writeVideo(OO_2,fr_O2);
close(OO_2);
%% CSIRO
Ful_3= VideoWriter('Full_CSIRO.avi');
Ful_3.FrameRate = 1;
fr_F3 = CMMovie(3,1,dsdt_JPL, dsdt_NCAR, dsdt_PIK1, dsdt_PIK2, dsdt_UAF1);
open(Ful_3);
writeVideo(Ful_3,fr_F3);
close(Ful_3);

AO_3= VideoWriter('AO_CSIRO.avi');
AO_3.FrameRate = 1;
fr_A3 = CMMovie(3,2,dsdt_JPL, dsdt_NCAR, dsdt_PIK1, dsdt_PIK2, dsdt_UAF1);
open(AO_3);
writeVideo(AO_3,fr_A3);
close(AO_3);

OO_3= VideoWriter('OO_CSIRO.avi');
OO_3.FrameRate = 1;
fr_O3 = CMMovie(3,3,dsdt_JPL, dsdt_NCAR, dsdt_PIK1, dsdt_PIK2, dsdt_UAF1);
open(OO_3);
writeVideo(OO_3,fr_O3);
close(OO_3);
%% ISM vs. CM
%% JPL-ISSM
Ful_1= VideoWriter('Full_JPL.avi');
Ful_1.FrameRate = 1;
fr_F1 = ISMovie(1,1,dsdt_JPL);
open(Ful_1);
writeVideo(Ful_1,fr_F1);
close(Ful_1);

AO_1= VideoWriter('AO_JPL.avi');
AO_1.FrameRate = 1;
fr_A1 = ISMovie(1,2,dsdt_JPL);
open(AO_1);
writeVideo(AO_1,fr_A1);
close(AO_1);

OO_1= VideoWriter('OO_JPL.avi');
OO_1.FrameRate = 1;
fr_O1 = ISMovie(1,3,dsdt_JPL);
open(OO_1);
writeVideo(OO_1,fr_O1);
close(OO_1);

%% NCAR-CISM
Ful_2= VideoWriter('Full_NCAR.avi');
Ful_2.FrameRate = 1;
fr_F2 = ISMovie(2,1,dsdt_NCAR);
open(Ful_2);
writeVideo(Ful_2,fr_F2);
close(Ful_2);

AO_2= VideoWriter('AO_NCAR.avi');
AO_2.FrameRate = 1;
fr_A2 = ISMovie(2,2,dsdt_NCAR);
open(AO_2);
writeVideo(AO_2,fr_A2);
close(AO_2);

OO_2= VideoWriter('OO_NCAR.avi');
OO_2.FrameRate = 1;
fr_O2 = ISMovie(2,3,dsdt_NCAR);
open(OO_2);
writeVideo(OO_2,fr_O2);
close(OO_2);

%% ITLS_PIK-SICOPOLIS1
Ful_3= VideoWriter('Full_PIK1.avi');
Ful_3.FrameRate = 1;
fr_F3 = ISMovie(3,1,dsdt_PIK1);
open(Ful_3);
writeVideo(Ful_3,fr_F3);
close(Ful_3);

AO_3= VideoWriter('AO_PIK1.avi');
AO_3.FrameRate = 1;
fr_A3 = ISMovie(3,2,dsdt_PIK1);
open(AO_3);
writeVideo(AO_3,fr_A3);
close(AO_3);

OO_3= VideoWriter('OO_PIK1.avi');
OO_3.FrameRate = 1;
fr_O3 = ISMovie(3,3,dsdt_PIK1);
open(OO_3);
writeVideo(OO_3,fr_O3);
close(OO_3);

%% ITLS_PIK-SICOPOLIS2
Ful_4= VideoWriter('Full_PIK2.avi');
Ful_4.FrameRate = 1;
fr_F4 = ISMovie(4,1,dsdt_PIK2);
open(Ful_4);
writeVideo(Ful_4,fr_F4);
close(Ful_4);

AO_4= VideoWriter('AO_PIK2.avi');
AO_4.FrameRate = 1;
fr_A4 = ISMovie(4,2,dsdt_PIK2);
open(AO_4);
writeVideo(AO_4,fr_A4);
close(AO_4);

OO_4= VideoWriter('OO_PIK2.avi');
OO_4.FrameRate = 1;
fr_O4 = ISMovie(4,3,dsdt_PIK2);
open(OO_4);
writeVideo(OO_4,fr_O4);
close(OO_4);

%% UAF_PISM1
Ful_5= VideoWriter('Full_UAF1.avi');
Ful_5.FrameRate = 1;
fr_F5 = ISMovie(5,1,dsdt_UAF1);
open(Ful_5);
writeVideo(Ful_5,fr_F5);
close(Ful_5);

AO_5= VideoWriter('AO_UAF1.avi');
AO_5.FrameRate = 1;
fr_A5 = ISMovie(5,2,dsdt_UAF1);
open(AO_5);
writeVideo(AO_5,fr_A5);
close(AO_5);

OO_5= VideoWriter('OO_UAF1.avi');
OO_5.FrameRate = 1;
fr_O5 = ISMovie(5,3,dsdt_UAF1);
open(OO_5);
writeVideo(OO_5,fr_O5);
close(OO_5);
