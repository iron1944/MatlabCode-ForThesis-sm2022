%% This is for loading and clearning up data.
clear

Data_organizer

%% Masking out Ocean
M_JPL = OceanMask(Dat_JPL);
M_NCAR = OceanMask(Dat_NCAR);
M_PIK1 = OceanMask(Dat_PIK1);
M_PIK2 = OceanMask(Dat_PIK2);
M_UAF1 = OceanMask(Dat_UAF1);
% M_UAF2 = OceanMask(Dat_UAF2);
%% Calculate change per year
dsdt_JPL = dsdt_conv(M_JPL);
dsdt_NCAR = dsdt_conv(M_NCAR);
dsdt_PIK1 = dsdt_conv(M_PIK1);
dsdt_PIK2 = dsdt_conv(M_PIK2);
dsdt_UAF1 = dsdt_conv(M_UAF1);
% dsdt_UAF2 = dsdt_conv(M_UAF2);

clear M_JPL M_NCAR M_PIK1 M_PIK2 M_UAF1 M_UAF2