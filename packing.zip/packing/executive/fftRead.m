% reading fft results
%% JPL
F = netcdf.open('F_JPL.nc','nc_nowrite');
% get variable ids
v11 = netcdf.inqVarID(F,'MIR_FL');
v12 = netcdf.inqVarID(F,'MIR_AO');
v13 = netcdf.inqVarID(F,'MIR_OO');
v21 = netcdf.inqVarID(F,'NOR_FL');
v22 = netcdf.inqVarID(F,'NOR_AO');
v23 = netcdf.inqVarID(F,'NOR_OO');
v31 = netcdf.inqVarID(F,'CSI_FL');
v32 = netcdf.inqVarID(F,'CSI_AO');
v33 = netcdf.inqVarID(F,'CSI_OO');
% get variable
F_JPL{1,1} = netcdf.getVar(F,v11);
F_JPL{1,2} = netcdf.getVar(F,v12);
F_JPL{1,3} = netcdf.getVar(F,v13);
F_JPL{2,1} = netcdf.getVar(F,v21);
F_JPL{2,2} = netcdf.getVar(F,v22);
F_JPL{2,3} = netcdf.getVar(F,v23);
F_JPL{3,1} = netcdf.getVar(F,v31);
F_JPL{3,2} = netcdf.getVar(F,v32);
F_JPL{3,3} = netcdf.getVar(F,v33);
clear F

%% NCAR
F = netcdf.open('F_NCAR.nc','nc_nowrite');
% get variable ids
v11 = netcdf.inqVarID(F,'MIR_FL');
v12 = netcdf.inqVarID(F,'MIR_AO');
v13 = netcdf.inqVarID(F,'MIR_OO');
v21 = netcdf.inqVarID(F,'NOR_FL');
v22 = netcdf.inqVarID(F,'NOR_AO');
v23 = netcdf.inqVarID(F,'NOR_OO');
v31 = netcdf.inqVarID(F,'CSI_FL');
v32 = netcdf.inqVarID(F,'CSI_AO');
v33 = netcdf.inqVarID(F,'CSI_OO');
% get variable
F_NCAR{1,1} = netcdf.getVar(F,v11);
F_NCAR{1,2} = netcdf.getVar(F,v12);
F_NCAR{1,3} = netcdf.getVar(F,v13);
F_NCAR{2,1} = netcdf.getVar(F,v21);
F_NCAR{2,2} = netcdf.getVar(F,v22);
F_NCAR{2,3} = netcdf.getVar(F,v23);
F_NCAR{3,1} = netcdf.getVar(F,v31);
F_NCAR{3,2} = netcdf.getVar(F,v32);
F_NCAR{3,3} = netcdf.getVar(F,v33);
clear F

%% PIK1
F = netcdf.open('F_PIK1.nc','nc_nowrite');
% get variable ids
v11 = netcdf.inqVarID(F,'MIR_FL');
v12 = netcdf.inqVarID(F,'MIR_AO');
v13 = netcdf.inqVarID(F,'MIR_OO');
v21 = netcdf.inqVarID(F,'NOR_FL');
v22 = netcdf.inqVarID(F,'NOR_AO');
v23 = netcdf.inqVarID(F,'NOR_OO');
v31 = netcdf.inqVarID(F,'CSI_FL');
v32 = netcdf.inqVarID(F,'CSI_AO');
v33 = netcdf.inqVarID(F,'CSI_OO');
% get variable
F_PIK1{1,1} = netcdf.getVar(F,v11);
F_PIK1{1,2} = netcdf.getVar(F,v12);
F_PIK1{1,3} = netcdf.getVar(F,v13);
F_PIK1{2,1} = netcdf.getVar(F,v21);
F_PIK1{2,2} = netcdf.getVar(F,v22);
F_PIK1{2,3} = netcdf.getVar(F,v23);
F_PIK1{3,1} = netcdf.getVar(F,v31);
F_PIK1{3,2} = netcdf.getVar(F,v32);
F_PIK1{3,3} = netcdf.getVar(F,v33);
clear F

%% PIK2
F = netcdf.open('F_PIK2.nc','nc_nowrite');
% get variable ids
v11 = netcdf.inqVarID(F,'MIR_FL');
v12 = netcdf.inqVarID(F,'MIR_AO');
v13 = netcdf.inqVarID(F,'MIR_OO');
v21 = netcdf.inqVarID(F,'NOR_FL');
v22 = netcdf.inqVarID(F,'NOR_AO');
v23 = netcdf.inqVarID(F,'NOR_OO');
v31 = netcdf.inqVarID(F,'CSI_FL');
v32 = netcdf.inqVarID(F,'CSI_AO');
v33 = netcdf.inqVarID(F,'CSI_OO');
% get variable
F_PIK2{1,1} = netcdf.getVar(F,v11);
F_PIK2{1,2} = netcdf.getVar(F,v12);
F_PIK2{1,3} = netcdf.getVar(F,v13);
F_PIK2{2,1} = netcdf.getVar(F,v21);
F_PIK2{2,2} = netcdf.getVar(F,v22);
F_PIK2{2,3} = netcdf.getVar(F,v23);
F_PIK2{3,1} = netcdf.getVar(F,v31);
F_PIK2{3,2} = netcdf.getVar(F,v32);
F_PIK2{3,3} = netcdf.getVar(F,v33);
clear F

%% UAF1
F = netcdf.open('F_UAF1.nc','nc_nowrite');
% get variable ids
v11 = netcdf.inqVarID(F,'MIR_FL');
v12 = netcdf.inqVarID(F,'MIR_AO');
v13 = netcdf.inqVarID(F,'MIR_OO');
v21 = netcdf.inqVarID(F,'NOR_FL');
v22 = netcdf.inqVarID(F,'NOR_AO');
v23 = netcdf.inqVarID(F,'NOR_OO');
v31 = netcdf.inqVarID(F,'CSI_FL');
v32 = netcdf.inqVarID(F,'CSI_AO');
v33 = netcdf.inqVarID(F,'CSI_OO');
% get variable
F_UAF1{1,1} = netcdf.getVar(F,v11);
F_UAF1{1,2} = netcdf.getVar(F,v12);
F_UAF1{1,3} = netcdf.getVar(F,v13);
F_UAF1{2,1} = netcdf.getVar(F,v21);
F_UAF1{2,2} = netcdf.getVar(F,v22);
F_UAF1{2,3} = netcdf.getVar(F,v23);
F_UAF1{3,1} = netcdf.getVar(F,v31);
F_UAF1{3,2} = netcdf.getVar(F,v32);
F_UAF1{3,3} = netcdf.getVar(F,v33);
clear F

%% clear up
clearvars -except F_JPL F_NCAR F_PIK1 F_PIK2 F_UAF1...
    dsdt_JPL dsdt_NCAR dsdt_PIK1 dsdt_PIK2 dsdt_UAF1
