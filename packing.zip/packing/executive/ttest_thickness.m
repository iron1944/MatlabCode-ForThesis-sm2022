%% Loading data
Data_clearup
fftRead
%%
[fulAO_JPL,fulOO_JPL]=d_ttest(dsdt_JPL,1,1);
[fulAO_NCAR,fulOO_NCAR]=d_ttest(dsdt_NCAR,2,1);
[fulAO_PIK1,fulOO_PIK1]=d_ttest(dsdt_PIK1,3,1);
[fulAO_PIK2,fulOO_PIK2]=d_ttest(dsdt_PIK2,4,1);
[fulAO_UAF1,fulOO_UAF1]=d_ttest(dsdt_UAF1,5,1);
%%
[fulAO_JPL_F,fulOO_JPL_F]=d_ttest(F_JPL,1,2);
[fulAO_NCAR_F,fulOO_NCAR_F]=d_ttest(F_NCAR,2,2);
[fulAO_PIK1_F,fulOO_PIK1_F]=d_ttest(F_PIK1,3,2);
[fulAO_PIK2_F,fulOO_PIK2_F]=d_ttest(F_PIK2,4,2);
[fulAO_UAF1_F,fulOO_UAF1_F]=d_ttest(F_UAF1,5,2);