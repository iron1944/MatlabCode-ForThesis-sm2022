%% Preparation
% prepare x/y coordinate
[x2d,y2d] = meshgrid((1:337),(1:577));

% read data coordinate
readcoor

%% Reading flowline coordinate
% % Jakobshavn
% F_JAK.x = ncread('glacier0001.nc','/flowline03/x');
% F_JAK.y = ncread('glacier0001.nc','/flowline03/y');
% [F_JAK.lat,F_JAK.lon] = gl_ps2ll(F_JAK.x,F_JAK.y);
% 
% % Humboldt
% F_HUM.x = ncread('glacier0098.nc','/flowline03/x');
% F_HUM.y = ncread('glacier0098.nc','/flowline03/y');
% [F_HUM.lat,F_HUM.lon] = gl_ps2ll(F_HUM.x,F_HUM.y);

% Zachariae
F_ZAC.x = ncread('glacier0115.nc','/flowline03/x');
F_ZAC.y = ncread('glacier0115.nc','/flowline03/y');
[F_ZAC.lat,F_ZAC.lon] = gl_ps2ll(F_ZAC.x,F_ZAC.y);

% % Kangerlussuaq
% F_KAN.x = ncread('glaciera173.nc','/flowline03/x');
% F_KAN.y = ncread('glaciera173.nc','/flowline03/y');
% [F_KAN.lat,F_KAN.lon] = gl_ps2ll(F_KAN.x,F_KAN.y);

%% Convert ps to ll
% [F_JAK.lat,F_JAK.lon] = gl_ps2ll(F_JAK.x,F_JAK.y);
% [F_HUM.lat,F_HUM.lon] = gl_ps2ll(F_HUM.x,F_HUM.y);
[F_ZAC.lat,F_ZAC.lon] = gl_ps2ll(F_ZAC.x,F_ZAC.y);
% [F_KAN.lat,F_KAN.lon] = gl_ps2ll(F_KAN.x,F_KAN.y);

%% Find corresponding x/y coor
% [F_JAK.px,F_JAK.py] = xycoor(F_JAK);
% [F_HUM.px,F_HUM.py] = xycoor(F_HUM);
[F_ZAC.px,F_ZAC.py] = xycoor(F_ZAC);
% [F_KAN.px,F_KAN.py] = xycoor(F_KAN);

%% dummy z for plotting
dz = 100000;
% F_JAK.z = dz*ones(1,length(F_JAK.x));
% F_HUM.z = dz*ones(1,length(F_HUM.x));
F_ZAC.z = dz*ones(1,length(F_ZAC.x));
% F_KAN.z = dz*ones(1,length(F_KAN.x));

%% dist
% F_JAK.dist = zeros(1,length(F_JAK.x));
% for ii = 2:length(F_JAK.x)
%     F_JAK.dist(1,ii)= sqrt((F_JAK.x(ii-1)-F_JAK.x(ii))^2+(F_JAK.y(ii-1)-F_JAK.y(ii))^2);
% end
% F_JAK.dist = cumsum(F_JAK.dist)';
% 
% F_HUM.dist = zeros(1,length(F_HUM.x));
% for ii = 2:length(F_HUM.x)
%     F_HUM.dist(1,ii)= sqrt((F_HUM.x(ii-1)-F_HUM.x(ii))^2+(F_HUM.y(ii-1)-F_HUM.y(ii))^2);
% end
% F_HUM.dist = cumsum(F_HUM.dist)';

F_ZAC.dist = zeros(1,length(F_ZAC.x));
for ii = 2:length(F_ZAC.x)
    F_ZAC.dist(1,ii)= sqrt((F_ZAC.x(ii-1)-F_ZAC.x(ii))^2+(F_ZAC.y(ii-1)-F_ZAC.y(ii))^2);
end
F_ZAC.dist = cumsum(F_ZAC.dist)';

% F_KAN.dist = zeros(1,length(F_KAN.x));
% for ii = 2:length(F_KAN.x)
%     F_KAN.dist(1,ii)= sqrt((F_KAN.x(ii-1)-F_KAN.x(ii))^2+(F_KAN.y(ii-1)-F_KAN.y(ii))^2);
% end
% F_KAN.dist = cumsum(F_KAN.dist)';

%% points
targetID = [544 4612 5615 10018];
targetx = F_ZAC.px(targetID);
targety = F_ZAC.py(targetID);

%% plot
cmaps

figure; clf; hold on
surf(x2d,y2d,Odom_SIC2{2}','Edgecolor','none')
view(2); box on; grid on;
axis equal; axis tight
colormap(RCP_T11)
% plot3(F_JAK.px,F_JAK.py,F_JAK.z,'m-','LineWidth',1.5)
% plot3(F_HUM.px,F_HUM.py,F_HUM.z,'g-','LineWidth',1.5)
plot(F_ZAC.px,F_ZAC.py,'c-','LineWidth',1.5)
% plot3(F_KAN.px,F_KAN.py,F_KAN.z,'k-','LineWidth',1.5)

for i=1:4
    plot3(targetx(i),targety(i),dz,'kd','LineWidth',2)
end

hold off
colorbar;
% legend('Dominance','JAK','HUM','ZAC','KAN','Location','southeast')
% title('Ocean forcing dominance plot with flowlines')
legend('Dominance','ZAC','CWT points','Location','southeast')
title('Zachariae Isstrom flowline on ocean dominace plot')