%% Read the lat/lon coordinate of the modelled domain
% for plotting

coor.lon = ncread('lithk_GIS_JPL_ISSM_exp05.nc','lon');
coor.lat = ncread('lithk_GIS_JPL_ISSM_exp05.nc','lat');