%% load
Data_clearup

%% JPL-MIROC
for ii = 1:3
   F_JPL_MIR{1,ii} = fft_full(dsdt_JPL{1,ii});
end
%% JPL-NorESM
for ii = 1:3
   F_JPL_NOR{2,ii} = fft_full(dsdt_JPL{2,ii});
end
%% JPL-CSIRO
for ii = 1:3
   F_JPL_CSI{3,ii} = fft_full(dsdt_JPL{3,ii});
end
%% compile
for ii=1:3
    F_JPL{1,ii}=F_JPL_MIR{1,ii};
    F_JPL{2,ii}=F_JPL_NOR{2,ii};
    F_JPL{3,ii}=F_JPL_CSI{3,ii};
end

%% NCAR-MIROC
for ii = 1:3
   F_NCAR_MIR{1,ii} = fft_full(dsdt_NCAR{1,ii});
end
%% NCAR-NorESM
for ii = 1:3
   F_NCAR_NOR{2,ii} = fft_full(dsdt_NCAR{2,ii});
end
%% NCAR-CSIRO
for ii = 1:3
   F_NCAR_CSI{3,ii} = fft_full(dsdt_NCAR{3,ii});
end
%% compile
for ii=1:3
    F_NCAR{1,ii}=F_NCAR_MIR{1,ii};
    F_NCAR{2,ii}=F_NCAR_NOR{2,ii};
    F_NCAR{3,ii}=F_NCAR_CSI{3,ii};
end


%% PIK1-MIROC
for ii = 1:3
   F_PIK1_MIR{1,ii} = fft_full(dsdt_PIK1{1,ii});
end
%% PIK1-NorESM
for ii = 1:3
   F_PIK1_NOR{2,ii} = fft_full(dsdt_PIK1{2,ii});
end
%% PIK1-CSIRO
for ii = 1:3
   F_PIK1_CSI{3,ii} = fft_full(dsdt_PIK1{3,ii});
end
%% compile
for ii=1:3
    F_PIK1{1,ii}=F_PIK1_MIR{1,ii};
    F_PIK1{2,ii}=F_PIK1_NOR{2,ii};
    F_PIK1{3,ii}=F_PIK1_CSI{3,ii};
end

%% PIK2-MIROC
for ii = 1:3
   F_PIK2_MIR{1,ii} = fft_full(dsdt_PIK2{1,ii});
end
%% PIK1-NorESM
for ii = 1:3
   F_PIK2_NOR{2,ii} = fft_full(dsdt_PIK2{2,ii});
end
%% PIK2-CSIRO
for ii = 1:3
   F_PIK2_CSI{3,ii} = fft_full(dsdt_PIK2{3,ii});
end
%% compile
for ii=1:3
    F_PIK2{1,ii}=F_PIK2_MIR{1,ii};
    F_PIK2{2,ii}=F_PIK2_NOR{2,ii};
    F_PIK2{3,ii}=F_PIK2_CSI{3,ii};
end

%% UAF1-MIROC
for ii = 1:3
   F_UAF1_MIR{1,ii} = fft_full(dsdt_UAF1{1,ii});
end
%% UAF1-NorESM
for ii = 1:3
   F_UAF1_NOR{2,ii} = fft_full(dsdt_UAF1{2,ii});
end
%% UAF1-CSIRO
for ii = 1:3
   F_UAF1_CSI{3,ii} = fft_full(dsdt_UAF1{3,ii});
end
%% compile
for ii=1:3
    F_UAF1{1,ii}=F_UAF1_MIR{1,ii};
    F_UAF1{2,ii}=F_UAF1_NOR{2,ii};
    F_UAF1{3,ii}=F_UAF1_CSI{3,ii};
end

%% plotting
%     ISMname = [' JPL-ISSM';
%         'NCAR-CISM';
%         'ILTS_PIK1';
%         'ILTS_PIK2';
%         'UAF-PISM1';
%         'UAF-PISM2'];
%     CMname = ['MIROC5';
%         'NorESM';
%         'CSIRO3'];
%     Forcing = ['Full';
%         ' AO ';
%         ' OO '];
% 
% L = 85;
% T = 60^2*24*365;
% f = (1/T)*(0:(L/2))/L;
% p = f.^(-1)/T;
% [x2d,y2d] = meshgrid((1:337),(1:577));
% 
% cmaps
% %% mask
% Masked = F_NCAR_MIR{1,1}(:,:,18);
% Masked(F_NCAR_MIR{1,1}(:,:,18)==0) = nan;
% 
% %% figure
% figure(1); clf
% surf(x2d,y2d,Masked','Edgecolor','none')
% view(2); box on;
% axis equal; axis tight
% colormap(RCP_T11)
% cb = colorbar;
% set(gca,'ColorScale','log')
% ylabel(cb,'Amplitude')
% title({['FFT at 5-year period,',Forcing(1,:)];
%         [ISMname(2,:),', ',CMname(1,:)]})
% %% t-test
% for ii=1:3
%     F_JPL{1,ii}=F_JPL_MIR{1,ii};
%     F_JPL{2,ii}=F_JPL_NOR{2,ii};
%     F_JPL{3,ii}=F_JPL_CSI{3,ii};
% end
% %%
% [fulAO,fulOO]=d_ttest(F_UAF1,5,2);