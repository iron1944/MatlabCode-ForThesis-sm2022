%% Reading .nc files
%% JPL
ncid = netcdf.open('lithk_GIS_JPL_ISSM_ctrl_proj.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_JPL_ctrl = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_JPL_ISSM_exp05.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_JPL_05 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_JPL_ISSM_exp06.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_JPL_06 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_JPL_ISSM_expa02.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_JPL_a2 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_JPL_ISSM_expc01.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_JPL_c1 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_JPL_ISSM_expc02.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_JPL_c2 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_JPL_ISSM_expc03.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_JPL_c3 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_JPL_ISSM_expc04.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_JPL_c4 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_JPL_ISSM_expc07.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_JPL_c7 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_JPL_ISSM_expc08.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_JPL_c8 = netcdf.getVar(ncid,varidGIS);
%% NCAR
ncid = netcdf.open('lithk_GIS_NCAR_CISM_ctrl_proj.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_NCAR_ctrl = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_NCAR_CISM_exp05.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_NCAR_05 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_NCAR_CISM_exp06.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_NCAR_06 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_NCAR_CISM_expa02.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_NCAR_a2 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_NCAR_CISM_expc01.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_NCAR_c1 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_NCAR_CISM_expc02.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_NCAR_c2 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_NCAR_CISM_expc03.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_NCAR_c3 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_NCAR_CISM_expc04.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_NCAR_c4 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_NCAR_CISM_expc07.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_NCAR_c7 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_NCAR_CISM_expc08.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_NCAR_c8 = netcdf.getVar(ncid,varidGIS);
%% ILTS_PIK1
ncid = netcdf.open('lithk_GIS_ILTS_PIK_SICOPOLIS1_ctrl_proj.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_PIK1_ctrl = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_ILTS_PIK_SICOPOLIS1_exp05.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_PIK1_05 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_ILTS_PIK_SICOPOLIS1_exp06.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_PIK1_06 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_ILTS_PIK_SICOPOLIS1_expa02.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_PIK1_a2 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_ILTS_PIK_SICOPOLIS1_expc01.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_PIK1_c1 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_ILTS_PIK_SICOPOLIS1_expc02.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_PIK1_c2 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_ILTS_PIK_SICOPOLIS1_expc03.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_PIK1_c3 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_ILTS_PIK_SICOPOLIS1_expc04.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_PIK1_c4 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_ILTS_PIK_SICOPOLIS1_expc07.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_PIK1_c7 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_ILTS_PIK_SICOPOLIS1_expc08.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_PIK1_c8 = netcdf.getVar(ncid,varidGIS);
%% ILTS_PIK2
ncid = netcdf.open('lithk_GIS_ILTS_PIK_SICOPOLIS2_ctrl_proj.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_PIK2_ctrl = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_ILTS_PIK_SICOPOLIS2_exp05.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_PIK2_05 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_ILTS_PIK_SICOPOLIS2_exp06.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_PIK2_06 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_ILTS_PIK_SICOPOLIS2_expa02.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_PIK2_a2 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_ILTS_PIK_SICOPOLIS2_expc01.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_PIK2_c1 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_ILTS_PIK_SICOPOLIS2_expc02.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_PIK2_c2 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_ILTS_PIK_SICOPOLIS2_expc03.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_PIK2_c3 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_ILTS_PIK_SICOPOLIS2_expc04.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_PIK2_c4 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_ILTS_PIK_SICOPOLIS2_expc07.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_PIK2_c7 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_ILTS_PIK_SICOPOLIS2_expc08.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_PIK2_c8 = netcdf.getVar(ncid,varidGIS);
%% UAF1
ncid = netcdf.open('lithk_GIS_UAF_PISM1_ctrl_proj.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_UAF1_ctrl = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_UAF_PISM1_exp05.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_UAF1_05 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_UAF_PISM1_exp06.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_UAF1_06 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_UAF_PISM1_expa02.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_UAF1_a2 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_UAF_PISM1_expc01.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_UAF1_c1 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_UAF_PISM1_expc02.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_UAF1_c2 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_UAF_PISM1_expc03.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_UAF1_c3 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_UAF_PISM1_expc04.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_UAF1_c4 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_UAF_PISM1_expc07.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_UAF1_c7 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_UAF_PISM1_expc08.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_UAF1_c8 = netcdf.getVar(ncid,varidGIS);
%% UAF2
ncid = netcdf.open('lithk_GIS_UAF_PISM2_ctrl_proj.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_UAF2_ctrl = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_UAF_PISM2_exp01.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_UAF2_01 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_UAF_PISM2_exp02.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_UAF2_02 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_UAF_PISM2_expa02.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_UAF2_a2 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_UAF_PISM2_expc01.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_UAF2_c1 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_UAF_PISM2_expc02.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_UAF2_c2 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_UAF_PISM2_expc03.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_UAF2_c3 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_UAF_PISM2_expc04.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_UAF2_c4 = netcdf.getVar(ncid,varidGIS);

% ncid = netcdf.open('lithk_GIS_UAF_PISM2_expc07.nc','nc_nowrite');
% varidGIS=netcdf.inqVarID(ncid,'lithk');
% lithk_UAF2_c7 = netcdf.getVar(ncid,varidGIS);

ncid = netcdf.open('lithk_GIS_UAF_PISM2_expc08.nc','nc_nowrite');
varidGIS=netcdf.inqVarID(ncid,'lithk');
lithk_UAF2_c8 = netcdf.getVar(ncid,varidGIS);
%% Organizer
% control projection
Dat_JPL{1,1} = lithk_JPL_ctrl;
Dat_JPL{2,1} = lithk_JPL_ctrl;
Dat_JPL{3,1} = lithk_JPL_ctrl;
Dat_NCAR{1,1} = lithk_NCAR_ctrl;
Dat_NCAR{2,1} = lithk_NCAR_ctrl;
Dat_NCAR{3,1} = lithk_NCAR_ctrl;
Dat_PIK1{1,1} = lithk_PIK1_ctrl;
Dat_PIK1{2,1} = lithk_PIK1_ctrl;
Dat_PIK1{3,1} = lithk_PIK1_ctrl;
Dat_PIK2{1,1} = lithk_PIK2_ctrl;
Dat_PIK2{2,1} = lithk_PIK2_ctrl;
Dat_PIK2{3,1} = lithk_PIK2_ctrl;
Dat_UAF1{1,1} = lithk_UAF1_ctrl;
Dat_UAF1{2,1} = lithk_UAF1_ctrl;
Dat_UAF1{3,1} = lithk_UAF1_ctrl;
Dat_UAF2{1,1} = lithk_UAF2_ctrl;
Dat_UAF2{2,1} = lithk_UAF2_ctrl;
Dat_UAF2{3,1} = lithk_UAF2_ctrl;
%% MIROC5
% JPL ISSM
Dat_JPL{1,2} = lithk_JPL_05;
Dat_JPL{1,3} = lithk_JPL_c1;
Dat_JPL{1,4} = lithk_JPL_c2;
% NCAR CISM 
Dat_NCAR{1,2} = lithk_NCAR_05;
Dat_NCAR{1,3} = lithk_NCAR_c1;
Dat_NCAR{1,4} = lithk_NCAR_c2;
% ILTS_PIK SICOPOLIS1
Dat_PIK1{1,2} = lithk_PIK1_05;
Dat_PIK1{1,3} = lithk_PIK1_c1;
Dat_PIK1{1,4} = lithk_PIK1_c2;
% ILTS_PIK SICOPOLIS1
Dat_PIK2{1,2} = lithk_PIK2_05;
Dat_PIK2{1,3} = lithk_PIK2_c1;
Dat_PIK2{1,4} = lithk_PIK2_c2;
% UAF PISM1
Dat_UAF1{1,2} = lithk_UAF1_05;
Dat_UAF1{1,3} = lithk_UAF1_c1;
Dat_UAF1{1,4} = lithk_UAF1_c2;
% UAF PISM2
Dat_UAF2{1,2} = lithk_UAF2_01;
Dat_UAF2{1,3} = lithk_UAF2_c1;
Dat_UAF2{1,4} = lithk_UAF2_c2;
%% NorESM
% JPL ISSM
Dat_JPL{2,2} = lithk_JPL_06;
Dat_JPL{2,3} = lithk_JPL_c7;
Dat_JPL{2,4} = lithk_JPL_c8;
% NCAR CISM 
Dat_NCAR{2,2} = lithk_NCAR_06;
Dat_NCAR{2,3} = lithk_NCAR_c7;
Dat_NCAR{2,4} = lithk_NCAR_c8;
% ILTS_PIK SICOPOLIS1
Dat_PIK1{2,2} = lithk_PIK1_06;
Dat_PIK1{2,3} = lithk_PIK1_c7;
Dat_PIK1{2,4} = lithk_PIK1_c8;
% ILTS_PIK SICOPOLIS1
Dat_PIK2{2,2} = lithk_PIK2_06;
Dat_PIK2{2,3} = lithk_PIK2_c7;
Dat_PIK2{2,4} = lithk_PIK2_c8;
% UAF PISM1
Dat_UAF1{2,2} = lithk_UAF1_06;
Dat_UAF1{2,3} = lithk_UAF1_c7;
Dat_UAF1{2,4} = lithk_UAF1_c8;
% UAF PISM2
Dat_UAF2{2,2} = lithk_UAF2_02;
% Dat_UAF2{2,3} = lithk_UAF2_c7;
Dat_UAF2{2,4} = lithk_UAF2_c8;
%% CSIRO-Mk3.6
% JPL ISSM
Dat_JPL{3,2} = lithk_JPL_a2;
Dat_JPL{3,3} = lithk_JPL_c3;
Dat_JPL{3,4} = lithk_JPL_c4;
% NCAR CISM 
Dat_NCAR{3,2} = lithk_NCAR_a2;
Dat_NCAR{3,3} = lithk_NCAR_c3;
Dat_NCAR{3,4} = lithk_NCAR_c4;
% ILTS_PIK SICOPOLIS1
Dat_PIK1{3,2} = lithk_PIK1_a2;
Dat_PIK1{3,3} = lithk_PIK1_c3;
Dat_PIK1{3,4} = lithk_PIK1_c4;
% ILTS_PIK SICOPOLIS1
Dat_PIK2{3,2} = lithk_PIK2_a2;
Dat_PIK2{3,3} = lithk_PIK2_c3;
Dat_PIK2{3,4} = lithk_PIK2_c4;
% UAF PISM1
Dat_UAF1{3,2} = lithk_UAF1_a2;
Dat_UAF1{3,3} = lithk_UAF1_c3;
Dat_UAF1{3,4} = lithk_UAF1_c4;
% UAF PISM2
Dat_UAF2{3,2} = lithk_UAF2_a2;
Dat_UAF2{3,3} = lithk_UAF2_c3;
Dat_UAF2{3,4} = lithk_UAF2_c4;
%% ISSM correction
% this is necessary because JPL's ISSM included one more year than every
% other ISMs

for i = 1:3
    for j =1:3
        Dat_JPL{i,j} = Dat_JPL{i,j}(:,:,2:87);
    end
end
%% Clear up
clearvars -except Dat_JPL Dat_NCAR Dat_PIK1 Dat_PIK2 Dat_UAF1 Dat_UAF2