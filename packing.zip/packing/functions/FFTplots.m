function [] = FFTplots(dat,fftID,N,M)
%FFTPLOTS is plotting only function, no output
%   dat     is the fft data
%   fftID   is the selected period to visualize
%   N       is the ice sheet model number of dat
%   M       is the climate model number

% setup
    ISMname = ['ISSM';
        'CISM';'PIK1';
        'PIK2';'PISM'];
    CMname = ['MIROC5';
        'NorESM';
        'CSIRO3'];
    period = [' 5-year';
        '10-year';
        '20-year';
        '40-year';
        ];
    cmaps
    limit = [0.001 10];
    [x2d,y2d] = meshgrid((1:337),(1:577));
    
% extract & mask
    mask_FL = dat{M,1}(:,:,fftID);
    mask_AO = dat{M,2}(:,:,fftID);
    mask_OO = dat{M,3}(:,:,fftID);
    mask_FL(mask_FL==0) = nan;
    mask_AO(mask_AO==0) = nan;
    mask_OO(mask_OO==0) = nan;
    

% plotting
fig = figure;
sgtitle({['FFT of full forcing'];
        [ISMname(N,:),', ',CMname(M,:)]})
for ii = 1:4
    subplot(2,2,ii)
    surf(x2d,y2d,mask_FL(:,:,ii)','Edgecolor','none')
    view(2); box on;
    axis equal; axis tight
    colormap(RCP_T11)
    set(gca,'ColorScale','log')
    caxis(limit)
    title(['',period(ii,:),''])
end
cb = colorbar('Location','eastoutside','Position',[0.8915,0.1060,0.0248,0.8048]);
ylabel(cb,'Amplitude')
set(fig,'Position',[680,42,734,953])

fig = figure;
sgtitle({['FFT of AO forcing'];
        [ISMname(N,:),', ',CMname(M,:)]})
for ii = 1:4
    subplot(2,2,ii)
    surf(x2d,y2d,mask_AO(:,:,ii)','Edgecolor','none')
    view(2); box on;
    axis equal; axis tight
    colormap(RCP_T11)
    set(gca,'ColorScale','log')
    caxis(limit)
    title(['',period(ii,:),''])
end
cb = colorbar('Location','eastoutside','Position',[0.8915,0.1060,0.0248,0.8048]);
ylabel(cb,'Amplitude')
set(fig,'Position',[680,42,734,953])

fig = figure;
sgtitle({['FFT of OO forcing'];
        [ISMname(N,:),', ',CMname(M,:)]})
for ii = 1:4
    subplot(2,2,ii)
    surf(x2d,y2d,mask_OO(:,:,ii)','Edgecolor','none')
    view(2); box on;
    axis equal; axis tight
    colormap(RCP_T11)
    set(gca,'ColorScale','log')
    caxis(limit)
    title(['',period(ii,:),''])
end
cb = colorbar('Location','eastoutside','Position',[0.8915,0.1060,0.0248,0.8048]);
ylabel(cb,'Amplitude')
set(fig,'Position',[680,42,734,953])
end

