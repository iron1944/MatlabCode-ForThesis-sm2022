function [frame] = ISMovie(m,n,dat)
%CMMOVIE make movie of one ISM/forcing pair under different climate models
%   In: m is the ISM number
%       n is the forcing type, 1-Full, 2-AO, 3-OO
%       dat1-5, ISSM-CISM-SICOPOLIS1&2-PISM1&2 in order
%   Out: frame for writing into .avi videos

% set up ISM and CM names for titles
    ISMname = ['ISSM';
        'CISM';'PIK1';
        'PIK2';'PISM'];
    CMname = ['MIROC5';
        'NorESM';
        'CSIRO3'];
    Forcing = ['Full';
        ' AO ';
        ' OO '];
    
    sz = size(dat{1,1});
    k = sz(1,3);
    dat = OceanMask(dat);

    cmaps

[x2d,y2d] = meshgrid((1:337),(1:577));

fr = 1;
fig1 = figure('position',[78,171,1359,789],'Color',[1,1,1]);

while fr<=k
    cla;
    
    sgtitle({['Ice thickness change, year = ',num2str(fr)];
            [Forcing(n,:),', in ',ISMname(m,:)]})
    
    subplot(1,3,1)
    surf(x2d,y2d,dat{1,n}(:,:,fr)','Edgecolor','none')
    view(2); box on;
    axis equal; axis tight
    colormap(RCP_T11)
    caxis([-5 5])
    title({[CMname(1,:)]})
    
    subplot(1,3,2)
    surf(x2d,y2d,dat{2,n}(:,:,fr)','Edgecolor','none')
    view(2); box on;
    axis equal; axis tight
    colormap(RCP_T11)
    caxis([-5 5])
    title({[CMname(2,:)]})
    
    subplot(1,3,3)
    surf(x2d,y2d,dat{3,n}(:,:,fr)','Edgecolor','none')
    view(2); box on;
    axis equal; axis tight
    colormap(RCP_T11)
    caxis([-5 5])
    title({[CMname(3,:)]})
    
    cb = colorbar('Location','southoutside','Position',[0.1303,0.0931,0.7766,0.0233]);
    ylabel(cb,'Thickness change (m)','FontSize',12)
    
    drawnow
    
    frame(fr) = getframe(fig1);
    fr = fr+1;
end

end