function [] = cwtCtrl(dat,ts,target,targetID,N,M)
%CWTCON is a plot only function that plots cwt of a time series dat under a
%           sample time ts

    ISMname = ['ISSM';
        'CISM';'PIK1';
        'PIK2';'PISM'];

    CMname = ['MIROC5';
        'NorESM';
        'CSIRO3'];
    Forcing = ['Full';
        ' AO ';
        ' OO '];

    cmaps
    
for ii = 1:length(targetID)
    main = figure;
    set(main,'Position',[680,42,560,953])
    sgtitle({['Zachariae Isstrom @ ',num2str(target(ii)/1e3),'km'];
        [ISMname(N,:),', ',CMname(M,:)]})
    for jj = 1:3
        subplot(3,1,jj)
        [cfs,fs] = cwt(dat{M,jj}(targetID(ii),:));
        h = pcolor(1:1:length(ts),fs,abs(cfs));
        colormap(RCP_T11)
        title(Forcing(jj,:));
        set(gca,'ColorScale','log')
        set(gca,'YScale','log','TickDir','out')
        set(h,'EdgeColor','none')
        xlabel('Year')
        ylabel('Normalized Frequency')
        yticks([0.05 0.1 0.2 0.4])
        caxis([0.001 10])
        clear cfs fs
    end
    cb = colorbar('Position',[0.9101,0.1070,0.0220,0.7954]);
    ylabel(cb,'Magnitude')
end
end

