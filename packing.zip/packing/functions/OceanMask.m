function [masked] = OceanMask(ori)
%OCEANMASK replaces the values in Ocean(0) with NaN
%   This reduces unnecessary calculations
%   INPUT: ori is the original data matrix
%   OUTPUT: masked is the data with Ocean removed

% Mask = NaN(337,577);
sz_in = size(ori);
sz_dat = size(ori{1,1});

a = sz_in(1,1);
b = sz_in(1,2);
e = sz_dat(1,3);

for i = 1:a
    for j = 1:b
        for t = 1:e
            mask = ori{i,j}(:,:,t);
            mask(ori{i,1}(:,:,1)==0) = nan;
            masked{i,j}(:,:,t) = mask;
        end
    end
end
    
end

