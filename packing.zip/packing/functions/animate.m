function frame = animate(dat,n,m)
%ANIMATE making animated plots of ice thickness change and forcing change
%   of dominace
    %   input: dat is the input lithk by ISM (3x4 cell) 
    %       n is the number for climate model 
    %           (1 = MIROC5, 2 = NorESM, 3 = CSIRO )
    %       m is the number representing ISM (for fig title)
    %       v is the video recording object
    %   output: Odom is the ocean dominated count
    %           v needed to be setup before running this function using
    %               the VideoWriter function in Matlab
    
% set up ISM and CM names
%     ISMname = ['      JPL-ISSM     ';
%         '     NCAR-CISM     ';
%         'ILTS_PIK-SICOPOLIS1';
%         'ILTS_PIK-SICOPOLIS2';
%         '     UAF-PISM1     ';
%         '     UAF-PISM2     '];
    ISMname = ['ISSM';
        'CISM';'PIK1';
        'PIK2';'PISM'];

    CMname = ['MIROC5';
        'NorESM';
        'CSIRO3'];
    
sz = size(dat{n,1});
% Odom = zeros(sz(1,1),sz(1,2));
k = sz(1,3);

dat = OceanMask(dat);

dsdt_full = dat{n,1};
dsdt_AO = dat{n,2};
dsdt_OO = dat{n,3};

% for x = 1:sz(1,1)
%     for y = 1:sz(1,2)
%         for t = 1:k
%             OO = dsdt_OO(x,y,t);
%             AO = dsdt_AO(x,y,t);
%             logic = isnan(AO);
% %             if AO == 0
%             if logic == 1                
%                 dom(x,y,t) = NaN;         % No Ice
%             elseif OO > 1000*AO
%                 dom(x,y,t) = 1;         % Ocean dominant
%                 Odom(x,y) = Odom(x,y) + 1;
%             elseif (1000*AO>OO)&&(OO>1.2*AO)
%                 dom(x,y,t) = 2;         % Ocean dominant lower
%                 Odom(x,y) = Odom(x,y) + 1;
%             elseif (1.2*AO>OO)&&(OO>0.8*AO)
%                 dom(x,y,t) = 3;         % No dominant
%             elseif 0.8*AO > OO
%                 dom(x,y,t) = 4;         % Atomspheric dominant
%             end
%         end
%         if Odom(x,y) == 0
%             Odom(x,y) = NaN;
%         end  
%     end
% end

cmaps
% readcoor

[x2d,y2d] = meshgrid((1:337),(1:577));
% x2d,y2d
% coor.lon,coor.lat

fr = 1;
fig1 = figure('Position',[3,271,1339,707],'Color',[1,1,1]);

while fr<=k
    cla;
    
    sgtitle({['Ice thickness change, year = ',num2str(fr)];
            [ISMname(m,:),', ',CMname(n,:)]})   
    
    subplot(1,3,1)
    surf(x2d,y2d,dsdt_full(:,:,fr)','Edgecolor','none')
    view(2); box on;
    axis equal; axis tight
    colormap(RCP_T11)
    caxis([-5 5]) 
    title('full')
    
    subplot(1,3,2)
    surf(x2d,y2d,dsdt_AO(:,:,fr)','Edgecolor','none')
    view(2); box on;
    axis equal; axis tight
    colormap(RCP_T11)
    caxis([-5 5]) 
    title('AO')
    
    subplot(1,3,3)
    surf(x2d,y2d,dsdt_OO(:,:,fr)','Edgecolor','none')
    view(2); box on;
    axis equal; axis tight
    colormap(RCP_T11)
    caxis([-5 5]) 
    title('OO')
    
    cb = colorbar('Location','southoutside','Position',[0.1466,0.07196,0.7169,0.0289]);
    ylabel(cb,'Thickness change (m)','FontSize',12)
%     subplot(2,2,4)
%     surf(coor.lon,coor.lat,dom(:,:,fr),'Edgecolor','none')
%     view(2); box on;
%     axis equal; axis tight
%     colormap(RCP_T11)
%     colorbar;
%     title('forcing dominance')
%     

    drawnow
%     
    frame(fr) = getframe(fig1);
    fr = fr+1;
end


% figure
% surf(x2d,y2d,Odom','Edgecolor','none')
% view(2); box on;
% axis equal; axis tight
% colormap(RCP_T11)
% colorbar;
% title({['Times OO dominated'];
%         [ISMname(m,:),', ',CMname(n,:)]})

end

