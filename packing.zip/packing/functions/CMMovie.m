function [frame] = CMMovie(m,n,dat1,dat2,dat3,dat4,dat5)
%CMMOVIE make movie of AO/OO/Full only under one climate model
%   In: m is the climate model number, 1-MIRCO, 2-NorESM, 3-CSIRO
%       n is the forcing type, 1-Full, 2-AO, 3-OO
%       dat1-5, ISSM-CISM-SICOPOLIS1&2-PISM1&2 in order
%   Out: frame for writing into .avi videos

% set up ISM and CM names for titles
    ISMname = ['ISSM';
        'CISM';'PIK1';
        'PIK2';'PISM'];
    CMname = ['MIROC5';
        'NorESM';
        'CSIRO3'];
    Forcing = ['Full';
        ' AO ';
        ' OO '];
    
    sz = size(dat5{1,1});
    k = sz(1,3);

    dat1 = OceanMask(dat1);
    dat2 = OceanMask(dat2);
    dat3 = OceanMask(dat3);
    dat4 = OceanMask(dat4);
    dat5 = OceanMask(dat5);
    
cmaps

[x2d,y2d] = meshgrid((1:337),(1:577));

fr = 1;
fig1 = figure('position',[100,89,800,906],'Color',[1,1,1]);

while fr<=k
    cla;
    
    sgtitle({['Ice thickness change, year = ',num2str(fr)];
            [Forcing(n,:),', under ',CMname(m,:)]})
    
    subplot(2,3,1)
    surf(x2d,y2d,dat1{m,n}(:,:,fr)','Edgecolor','none')
    view(2); box on;
    axis equal; axis tight
    colormap(RCP_T11)
    caxis([-5 5])
    title({[ISMname(1,:)]})
    
    subplot(2,3,2)
    surf(x2d,y2d,dat2{m,n}(:,:,fr)','Edgecolor','none')
    view(2); box on;
    axis equal; axis tight
    colormap(RCP_T11)
    caxis([-5 5])
    title({[ISMname(2,:)]})
    
    subplot(2,3,3)
    surf(x2d,y2d,dat3{m,n}(:,:,fr)','Edgecolor','none')
    view(2); box on;
    axis equal; axis tight
    colormap(RCP_T11)
    caxis([-5 5])
    title({[ISMname(3,:)]})
    
    subplot(2,3,4)
    surf(x2d,y2d,dat4{m,n}(:,:,fr)','Edgecolor','none')
    view(2); box on;
    axis equal; axis tight
    colormap(RCP_T11)
    caxis([-5 5])
    title({[ISMname(4,:)]})
    
    subplot(2,3,5)
    surf(x2d,y2d,dat5{m,n}(:,:,fr)','Edgecolor','none')
    view(2); box on;
    axis equal; axis tight
    colormap(RCP_T11)
    caxis([-5 5])
    title({[ISMname(5,:)]})
    
    cb = colorbar('Location','eastoutside','Position',[0.7848,0.0906,0.0173,0.3789]);
    ylabel(cb,'Thickness change (m)','FontSize',12)
    
    drawnow
    
    frame(fr) = getframe(fig1);
    fr = fr+1;
end

end

