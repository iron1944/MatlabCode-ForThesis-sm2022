function [FFT,dh] = FFTdhGrab(F,dsdt_ISM,FFT_ISM)
%FFTDHGRAB is for grabing the thickness change and FFT result along a given
%       flowline F
%   F is flowline information; FFT_ISM and dsdt_ISM is the FFT result and
%   thickness change respectively
%   FFT and dh would be the cooresponding FFT results and thickness change
%   along the flowline

% FFT
for ii = 1:length(F.x)
    for jj = 1:length(F.p)
        for kk = 1:3
            for ll = 1:3
                FFT{kk,ll}(ii,jj) = FFT_ISM{kk,ll}(F.x(ii),F.y(ii),jj); 
            end
        end
    end
end

% dh
for ii = 1:length(F.x)
    for jj = 1:length(F.yr)
        for kk = 1:3
            for ll = 1:3
                dh{kk,ll}(ii,jj) = dsdt_ISM{kk,ll}(F.x(ii),F.y(ii),jj); 
            end
        end
    end
end

end

