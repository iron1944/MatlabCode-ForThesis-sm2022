function [] = FL_plots(F,dat,M,FLname)
%FL_PLOTS is a plot only function
%   which plot a dataset dat along the flowline F
%   M is the Ice Sheet model number
%   FLname is the string for the name of flowline

    ISMname = ['ISSM';
        'CISM';'PIK1';
        'PIK2';'PISM'];

    CMname = ['MIROC5';
        'NorESM';
        'CSIRO3'];
    Forcing = ['Full';
        ' AO ';
        ' OO '];
    cmaps
    
for ii = 1:3
fig = figure;
sgtitle({['FFT along ',FLname];
        [ISMname(M,:),', ',CMname(ii,:)]})
set(fig,'Position',[670,42,894,953])

subplot(3,1,1)
imagesc(F.dist/1e3,F.p(2:end),dat{ii,1}(:,2:end)')
colormap(RCP_T11)
set(gca,'ColorScale','log')
set(gca,'YScale','log')
set(gca,'TickDir','out');
xlabel('km from start of flowline')
ylabel('period (yr)')
yticks([5 10 20 40 80])
caxis([0.001 10])
title(Forcing(1,:))

subplot(3,1,2)
imagesc(F.dist/1e3,F.p(2:end),dat{ii,2}(:,2:end)')
colormap(RCP_T11)
set(gca,'ColorScale','log')
set(gca,'YScale','log')
set(gca,'TickDir','out');
xlabel('km from start of flowline')
ylabel('period (yr)')
yticks([5 10 20 40 80])
caxis([0.001 10])
title(Forcing(2,:))

subplot(3,1,3)
imagesc(F.dist/1e3,F.p(2:end),dat{ii,3}(:,2:end)')
colormap(RCP_T11)
set(gca,'ColorScale','log')
set(gca,'YScale','log')
set(gca,'TickDir','out');
xlabel('km from start of flowline')
ylabel('period (yr)')
yticks([5 10 20 40 80])
caxis([0.001 10])
title(Forcing(3,:))

cb = colorbar('Location','eastoutside','Position',[0.9146,0.1070,0.0148,0.7943]);
ylabel(cb,'Amplitude')

end
end

