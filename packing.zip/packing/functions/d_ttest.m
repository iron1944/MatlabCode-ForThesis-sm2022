function [d_fulAO,d_fulOO] = d_ttest(dat,N,M)
%d_ttest 此处显示有关此函数的摘要
%   dat -- input data
%   N   -- ISM name
%   M   -- Analysis type
%% Prepare
sz = size(dat{1,1});

A_T = ['dsdt'; ' FFT'];

    ISMname = ['ISSM';
        'CISM';'PIK1';
        'PIK2';'PISM'];

cm = [0 0 1;
    1 0 0];
    
%% T-test

for i = 1:3
    for m = 1:337
        for n = 1:577
            dful = dat{i,1}(m,n,:);
            dAO = dat{i,2}(m,n,:);
            dOO = dat{i,3}(m,n,:);
            d_fulAO{1,i}(m,n) = ttest2(dful,dAO,'Vartype','unequal');
            d_fulOO{1,i}(m,n) = ttest2(dful,dOO,'Vartype','unequal');
        end
    end
end

%% Masking
% Mask = NaN(337,577);
% for m = 1:337
%     for n = 1:577
%         if dat{1,1}(m,n,1)~=0
%             Mask(m,n) = 1;
%         end
%     end
% end

% for i = 1:3
%     for m = 1:337
%         for n = 1:577
%             if Mask(m,n) ==1 && isnan(d_fulAO{1,i}(m,n))
%                 d_fulAO{1,i}(m,n)=0.4;
%             end
%             if Mask(m,n) ==1 && isnan(d_fulOO{1,i}(m,n))
%                 d_fulOO{1,i}(m,n)=0.4;
%             end
%         end
%     end
% end

for i=1:3
    d_fulAO{1,i}(dful(:,:,1)==0)=nan;
    d_fulOO{1,i}(dful(:,:,1)==0)=nan;
end

%% plotting

[x2d,y2d] = meshgrid((1:337),(1:577));

fig = figure;
sgtitle(['T test, ',A_T(M,:),', ',ISMname(N,:)])
subplot(2,3,1);
surf(x2d,y2d,d_fulAO{1,1}','Edgecolor','none')
set(gca,'FontSize',12)
view(2); box on;
axis equal; axis tight
colormap(cm)
title('MIROC,Full vs. AO')

subplot(2,3,2);
surf(x2d,y2d,d_fulAO{1,2}','Edgecolor','none')
set(gca,'FontSize',12)
view(2); box on;
axis equal; axis tight
title('NorESM,Full vs. AO')

subplot(2,3,3);
surf(x2d,y2d,d_fulAO{1,3}','Edgecolor','none')
set(gca,'FontSize',12)
view(2); box on;
axis equal; axis tight
colormap(cm)
title('CSIRO,Full vs. AO')

subplot(2,3,4);
surf(x2d,y2d,d_fulOO{1,1}','Edgecolor','none')
set(gca,'FontSize',12)
view(2); box on;
axis equal; axis tight
colormap(cm)
title('MIROC,Full vs. OO')

subplot(2,3,5);
surf(x2d,y2d,d_fulOO{1,2}','Edgecolor','none')
set(gca,'FontSize',12)
view(2); box on;
axis equal; axis tight
colormap(cm)
title('NorESM,Full vs. OO')

subplot(2,3,6);
surf(x2d,y2d,d_fulOO{1,3}','Edgecolor','none')
set(gca,'FontSize',12)
view(2); box on;
axis equal; axis tight
colormap(cm)
title('CSIRO,Full vs. OO')

set(fig,'Position',[842,77,1076,913])
cp = [0.8939 0.0986 0.01131 0.8072];
colorbar('YTick',linspace(0,1,2),'TickDirection','out','Position',cp,'TickLabels',{'Not rejected','  Rejected  '},'FontSize',9);
caxis([-0.45 1.45])
end
