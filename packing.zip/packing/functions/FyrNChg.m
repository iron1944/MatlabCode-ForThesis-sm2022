function [] = FyrNChg(m,n,dat1,dat2,dat3,dat4,dat5)
%FYRNCHG make screenshot of AO/OO/Full only under one climate model at the
%           final year and the total change
%   In: m is the climate model number, 1-MIRCO, 2-NorESM, 3-CSIRO
%       n is the forcing type, 1-Full, 2-AO, 3-OO
%       dat1-5, ISSM-CISM-SICOPOLIS1&2-PISM1&2 in order
%   Out: frame for writing into .avi videos

    ISMname = [' JPL-ISSM';
        'NCAR-CISM';
        'ILTS_PIK1';
        'ILTS_PIK2';
        'UAF-PISM1';
        'UAF-PISM2'];
    CMname = ['MIROC5';
        'NorESM';
        'CSIRO3'];
    Forcing = ['Full';
        ' AO ';
        ' OO '];

%% getting total change
sz = size(dat5{1,1});

for i = 1:sz(1,1)
    for j = 1:sz(1,2)
        delta_T1(i,j) = sum(dat1{m,n}(i,j,:));
        delta_T2(i,j) = sum(dat2{m,n}(i,j,:));
        delta_T3(i,j) = sum(dat3{m,n}(i,j,:));
        delta_T4(i,j) = sum(dat4{m,n}(i,j,:));
        delta_T5(i,j) = sum(dat5{m,n}(i,j,:));
    end
end

cmaps

[x2d,y2d] = meshgrid((1:337),(1:577));

%% Plotting
fig = figure('position',[100 100 1750 900]);

sgtitle({['Ice thickness change at final simulation year, and the total change'];
         [Forcing(n,:),', under ',CMname(m,:)]})

subplot(2,5,1)
surf(x2d,y2d,dat1{m,n}(:,:,85)','Edgecolor','none')
view(2); box on;
axis equal; axis tight
colormap(RCP_T11)
colorbar;
caxis([-5 5])
title({[ISMname(1,:)]})

subplot(2,5,6)
surf(x2d,y2d,delta_T1','Edgecolor','none')
view(2); box on;
axis equal; axis tight
colormap(RCP_T11)
colorbar;
caxis([-50 50])
title({[ISMname(1,:)],' total'})

subplot(2,5,2)
surf(x2d,y2d,dat2{m,n}(:,:,85)','Edgecolor','none')
view(2); box on;
axis equal; axis tight
colormap(RCP_T11)
colorbar;
caxis([-5 5])
title({[ISMname(2,:)]})

subplot(2,5,7)
surf(x2d,y2d,delta_T2','Edgecolor','none')
view(2); box on;
axis equal; axis tight
colormap(RCP_T11)
colorbar;
caxis([-50 50])
title({[ISMname(2,:)],' total'})

subplot(2,5,3)
surf(x2d,y2d,dat3{m,n}(:,:,85)','Edgecolor','none')
view(2); box on;
axis equal; axis tight
colormap(RCP_T11)
colorbar;
caxis([-5 5])
title({[ISMname(3,:)]})

subplot(2,5,8)
surf(x2d,y2d,delta_T3','Edgecolor','none')
view(2); box on;
axis equal; axis tight
colormap(RCP_T11)
colorbar;
caxis([-50 50])
title({[ISMname(3,:)],' total'})

subplot(2,5,4)
surf(x2d,y2d,dat4{m,n}(:,:,85)','Edgecolor','none')
view(2); box on;
axis equal; axis tight
colormap(RCP_T11)
colorbar;
caxis([-5 5])
title({[ISMname(4,:)]})

subplot(2,5,9)
surf(x2d,y2d,delta_T4','Edgecolor','none')
view(2); box on;
axis equal; axis tight
colormap(RCP_T11)
colorbar;
caxis([-50 50])
title({[ISMname(4,:)],' total'})

subplot(2,5,5)
surf(x2d,y2d,dat5{m,n}(:,:,85)','Edgecolor','none')
view(2); box on;
axis equal; axis tight
colormap(RCP_T11)
colorbar;
caxis([-5 5])
title({[ISMname(5,:)]})

subplot(2,5,10)
surf(x2d,y2d,delta_T5','Edgecolor','none')
view(2); box on;
axis equal; axis tight
colormap(RCP_T11)
colorbar;
caxis([-50 50])
title({[ISMname(5,:)],' total'})


end

