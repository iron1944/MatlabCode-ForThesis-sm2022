function [Odom,logic] = Odom(dat,n,m)
%ODOM only returns the Ocean dominance graph
%   input: dat is the input dsdt by ISM (3x3 cell) 
%       n is the number for climate model 
%           (1 = MIROC5, 2 = NorESM, 3 = CSIRO )
%       m is the number representing ISM (for fig title)
%   output: Odom is the ocean dominated count

% set up ISM and CM names
    ISMname = ['ISSM';
        'CISM';'PIK1';
        'PIK2';'PISM'];
    CMname = ['MIROC5';
        'NorESM';
        'CSIRO3'];

sz = size(dat{n,1});
Odom = zeros(sz(1,1),sz(1,2));
k = sz(1,3);

dat = OceanMask(dat);

dsdt_full = dat{n,1};
dsdt_AO = dat{n,2};
dsdt_OO = dat{n,3};

ini = dsdt_full(:,:,1);

logic = ones(sz(1,1),sz(1,2));
logic(isnan(ini)) = nan;


for x = 1:sz(1,1)
    for y = 1:sz(1,2)
        for t = 1:k
            OO = dsdt_OO(x,y,t);
            AO = dsdt_AO(x,y,t);
            if abs(OO) > 1.2*abs(AO)
%             if OO > 1.2*AO
                Odom(x,y) = Odom(x,y) + 1;
            end
        end
    end
end

Odom(isnan(logic))=nan;

[x2d,y2d] = meshgrid((1:337),(1:577));
cmaps

fig = figure; clf
surf(x2d,y2d,Odom','Edgecolor','none')
view(2); box on;
axis equal; axis tight
colormap(RCP_T11)
cb = colorbar;
ylabel(cb,'Dominance counts')
caxis([0 85])
title({['Times OO dominated'];
        [ISMname(m,:),', ',CMname(n,:)]})
set(fig,'Position',[680,42,775,953])
drawnow
end

