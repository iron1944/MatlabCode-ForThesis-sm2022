function dsdt = dsdt_conv(dat)
%DSDT_CONV converts the thickness data to thickness change per year
%           simulated
%   Input: dat is the thickness data for each simulation year
%   Output: dsdt is the array with thickness change per simulation year

sz = size(dat{1,1});
k = sz(1,3)-1;
for m = 1:3
    for n = 1:3
        for i= 1:k
            if isnan(dat{m,n+1}(:,:,i+1))
                dsdt{m,n}(:,:,i) = NaN;
            else
                dsdt{m,n}(:,:,i) = dat{m,n+1}(:,:,i+1) - dat{m,n+1}(:,:,i);
            end
        end
    end
end

end

