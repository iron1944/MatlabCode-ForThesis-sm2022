function [x,y] = xycoor(F)
%XYCOOR is temporally function for converting flowline lat/lon to plotted
%       x/y
%   F is the input struct with variable: lat and lon

readcoor

for ii = 1:length(F.x)
    lldif{ii} = abs(coor.lon-F.lon(ii))+abs(coor.lat-F.lat(ii));
    [~,id(ii)] = min(lldif{ii},[],'all','linear');
    y(ii) = floor(id(ii)/337);
    x(ii) = id(ii)-y(ii)*337;
end

end

