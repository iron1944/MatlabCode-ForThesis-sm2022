function [Out] = fft_full(In)
%fft_full 此处显示有关此函数的摘要
%   此处显示详细说明

sz = size(In);      % sizing input
mm = sz(1,1);       % x
nn = sz(1,2);       % y
oo = sz(1,3);       % and time
In_morph = reshape(In,[mm*nn,oo]);  % collapse spatial variable 
ii = 0;             % set up counter
while ii<(mm*nn)
    ii = ii+1;
    f = fft(In_morph(ii,:),oo);     % perform FFT
    P2 = abs(f/oo);
    P = P2(1:oo/2+1);
    P(2:end-1) = 2*P(2:end-1);
    pO(ii,:) = P;
end
sP = size(P);
Out = reshape(pO,[mm,nn,sP(1,2)]);      % return the spatial variable
end

