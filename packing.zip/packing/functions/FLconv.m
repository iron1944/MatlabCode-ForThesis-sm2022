function [F] = FLconv(F)
%FLCONV is to elaborate necesary info for the analysis along each flowline
%   The input F contains the original x y coordinate of flowline under
%   polar stereographic, and the x y must named psx and psy
%   The output F contain the polar stereographic x/y, converted lat/lon,
%   x/y coordinates in the model, plus the distance from start of
%   flowline,time by years, and the frequency spectrum

%% code start

% read model coordinate
readcoor

% lat/lon convertion
[F.lat,F.lon] = gl_ps2ll(F.psx,F.psy);  

% find the cooresponding model x/y
for ii = 1:length(F.psx)
    lldif{ii} = abs(coor.lon-F.lon(ii))+abs(coor.lat-F.lat(ii));
    [~,id(ii)] = min(lldif{ii},[],'all','linear');
    F.y(ii) = floor(id(ii)/337);
    F.x(ii) = id(ii)-F.y(ii)*337;
end

% calculate the distance to the start of flowline
F.dist = zeros(1,length(F.psx));
for ii = 2:length(F.psx)
    F.dist(1,ii)= sqrt((F.psx(ii-1)-F.psx(ii))^2+(F.psy(ii-1)-F.psy(ii))^2);
end
F.dist = cumsum(F.dist)';

% model time
F.yr = [1:1:85];

% FFT period spectrum
T = 60^2*24*365;
L = 85;
f = (1/T)*(0:(L/2))/L;
F.p = f.^(-1)/T;              %convert frequency(Hz) to period(yr)
end

