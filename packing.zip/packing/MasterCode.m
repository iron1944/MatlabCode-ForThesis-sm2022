%% Read before running!!!
%   This is the master code for The MS Thesis: Statistic and harmonic 
% analysis for forcing fingerprint on ISMIP6 modeled Greenland ice 
% thickness time series. This file should be used for running other codes
% (in the "executive" folder) for recreating the results in the Thesis. 
%   Please download the complete dataset from UB box: https://buffalo.box.com/s/qqefzq8e31j9b7wi5vcacgd7r96l3h86
% and add all data / codes (including subfolders) into matlab path before
% running the Master code. This Master code can be run directly, however,
% this is NOT RECOMMENTED due to optimization of some of the codes. This
% Master code is best run by sections.

%           Da Lin, 08/18/2022

%% Data availibility
%   The required dataset is initially upload to UB box. If the link provide
% above is no longer accessable, please contact dlin25@buffalo.edu or
% open an Issue in the Code's GitHub repository, so I can work out and
% alternative access.

%% Loading data
Data_clearup
% This file reads and organizes the orginal ISMIP6 thickness simulation
% results, and derives the thickness change data

%% Time series movies (need loading data)
makingmovies
% This file creates time series movies at the current directory, I suggest
% run this (makingmovies.m) by sections avoid flooding current directory. 

%% Ocean dominance plots (need loading data)
OnlyOdom
% This file creates ocean dominace plots

%% Ice sheet-wide FFT
FFT_final
% WARNING!!! Badly optimized code, expect long runtime. See next section
% for alternative.

%% Read FFT data
fftRead
% This is an oversight due to the badly optimized FFT_final file, it reads
% saved FFT data to bypass the long runtime.

%% Plotting ice sheet-wide FFT (need FFT data)
slctFFT
% This file produces FFT figures for selected periods/frequecies.

%% Regional harmonic analysis
CaseSpecific
% This file plots FFT results along the flowline, as well as preforms CWT
% analysis at selected points on the flowline.

%% T-test
ttest_thickness
% This file preforms two-sample T-test between AO/OO result and the full
% forcing result, and t-test figures.
